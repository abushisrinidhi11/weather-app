// Constants
const API_KEY = 'b99afe2e44214ad39ef91443250706';
const WEATHER_API_BASE_URL = 'https://api.weatherapi.com/v1';

// DOM Elements
const locationSearch = document.getElementById('locationSearch');
const searchButton = document.getElementById('searchButton');
const currentWeather = document.getElementById('currentWeather');
const forecast = document.getElementById('forecast');
const airQuality = document.getElementById('airQuality');
const weatherAlerts = document.getElementById('weatherAlerts');
const favoritesList = document.getElementById('favoritesList');
const toast = document.getElementById('toast');
const voiceSearchButton = document.getElementById('voiceSearchButton');

// Event Listeners
searchButton.addEventListener('click', handleSearch);
locationSearch.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') handleSearch();
});

// Initialize
loadFavorites();
if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
        position => getWeatherByCoords(position.coords.latitude, position.coords.longitude),
        error => showToast('Please enable location access or search for a location')
    );
}

// Chart instances
let tempChart = null;
let metricsChart = null;

// Initialize charts
function initializeCharts() {
    const tempCtx = document.getElementById('tempChart').getContext('2d');
    const metricsCtx = document.getElementById('metricsChart').getContext('2d');

    // Temperature chart
    tempChart = new Chart(tempCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Temperature (°C)',
                data: [],
                borderColor: '#2563eb',
                tension: 0.3,
                fill: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: false
                }
            }
        }
    });

    // Metrics chart
    metricsChart = new Chart(metricsCtx, {
        type: 'bar',
        data: {
            labels: ['Humidity', 'Wind Speed', 'Feels Like'],
            datasets: [{
                data: [],
                backgroundColor: [
                    'rgba(37, 99, 235, 0.6)',
                    'rgba(59, 130, 246, 0.6)',
                    'rgba(96, 165, 250, 0.6)'
                ],
                borderColor: [
                    'rgba(37, 99, 235, 1)',
                    'rgba(59, 130, 246, 1)',
                    'rgba(96, 165, 250, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// Main Functions
async function handleSearch() {
    const location = locationSearch.value.trim();
    if (!location) {
        showToast('Please enter a location');
        return;
    }
    
    // Show loading state
    searchButton.innerHTML = '<div class="loading"></div>';
    searchButton.disabled = true;
    
    try {
        const weather = await getWeatherByLocation(location);
        updateWeatherDisplay(weather);
        locationSearch.value = '';
    } catch (error) {
        showToast('Error fetching weather data. Please check the location name.');
        console.error(error);
    } finally {
        searchButton.innerHTML = 'Search';
        searchButton.disabled = false;
    }
}

async function getWeatherByLocation(location) {
    const response = await fetch(
        `${WEATHER_API_BASE_URL}/forecast.json?key=${API_KEY}&q=${encodeURIComponent(location)}&days=5&aqi=yes`
    );
    if (!response.ok) throw new Error('Weather data fetch failed');
    return await response.json();
}

async function getWeatherByCoords(lat, lon) {
    try {
        const weather = await getWeatherByLocation(`${lat},${lon}`);
        updateWeatherDisplay(weather);
    } catch (error) {
        showToast('Error fetching weather data');
        console.error(error);
    }
}

function updateWeatherDisplay(data) {
    // Update current weather
    currentWeather.innerHTML = `
        <h2>${data.location.name}, ${data.location.country}</h2>
        <div class="weather-details">
            <img src="https:${data.current.condition.icon}" alt="${data.current.condition.text}">
            <div class="weather-info">
                <div class="temperature">${Math.round(data.current.temp_c)}°C</div>
                <div class="condition">${data.current.condition.text}</div>
                <div class="details">
                    <div class="detail-item">Humidity: ${data.current.humidity}%</div>
                    <div class="detail-item">Wind: ${Math.round(data.current.wind_kph)} km/h</div>
                    <div class="detail-item">Feels like: ${Math.round(data.current.feelslike_c)}°C</div>
                </div>
            </div>
        </div>
        <button onclick="toggleFavorite('${data.location.name}')" class="favorite-btn">
            ${isFavorite(data.location.name) ? '★' : '☆'}
        </button>
    `;

    // Update forecast
    forecast.innerHTML = data.forecast.forecastday.map(day => `
        <div class="forecast-card">
            <div class="date">${formatDate(day.date)}</div>
            <img src="https:${day.day.condition.icon}" alt="${day.day.condition.text}">
            <div class="temp-range">
                <span>${Math.round(day.day.maxtemp_c)}°</span>
                <span>${Math.round(day.day.mintemp_c)}°</span>
            </div>
            <div class="condition">${day.day.condition.text}</div>
        </div>
    `).join('');    // Update air quality
    updateAirQuality(data.current.air_quality);    // Update weather alerts if any
    updateWeatherAlerts(data.alerts?.alert || [], data);

    // Update charts with new data
    updateCharts(data);

    // Update charts with new weather data
    updateCharts(data);
}

function updateAirQuality(aqData) {
    if (!aqData) {
        airQuality.innerHTML = `
            <h3>Air Quality</h3>
            <p style="color: #6b7280;">Air quality data not available</p>
        `;
        return;
    }
    
    const aqiValue = Math.round(aqData['us-epa-index']) || 'N/A';
    airQuality.innerHTML = `
        <h3>Air Quality</h3>
        <div class="aqi-value">${aqiValue}</div>
        <div class="aqi-description">${getAQIDescription(aqData['us-epa-index'])}</div>
        <div style="margin-top: 1rem; font-size: 0.9rem; color: #6b7280;">
            <div>CO: ${aqData.co?.toFixed(1) || 'N/A'} μg/m³</div>
            <div>NO₂: ${aqData.no2?.toFixed(1) || 'N/A'} μg/m³</div>
            <div>O₃: ${aqData.o3?.toFixed(1) || 'N/A'} μg/m³</div>
        </div>
    `;
}

// Generate custom weather alerts based on conditions
function generateCustomAlerts(data) {
    const alerts = [];
    const temp = data.current.temp_c;
    const condition = data.current.condition.text.toLowerCase();
    const humidity = data.current.humidity;
    const windKph = data.current.wind_kph;

    // Temperature-based alerts
    if (temp >= 35) {
        alerts.push({
            event: 'Extreme Heat Warning',
            desc: '🌡️ High temperature detected. Stay hydrated, avoid outdoor activities during peak hours, and seek shade when possible.'
        });
    } else if (temp <= 5) {
        alerts.push({
            event: 'Cold Weather Alert',
            desc: '❄️ Very cold conditions. Dress in warm layers and protect exposed skin. Be careful of icy surfaces.'
        });
    }

    // Rain-related alerts
    if (condition.includes('rain') || condition.includes('drizzle')) {
        alerts.push({
            event: 'Rain Advisory',
            desc: '☔ Rainy conditions expected. Carry an umbrella, be prepared for possible power cuts, and drive carefully on wet roads.'
        });
    }

    // Storm-related alerts
    if (condition.includes('thunder') || condition.includes('storm')) {
        alerts.push({
            event: 'Storm Warning',
            desc: '⛈️ Thunderstorm activity detected. Stay indoors, unplug electronic devices, and be prepared for power outages.'
        });
    }

    // Wind-related alerts
    if (windKph > 40) {
        alerts.push({
            event: 'High Wind Advisory',
            desc: '💨 Strong winds detected. Secure loose outdoor items and be cautious of falling branches.'
        });
    }

    // Humidity-related alerts
    if (humidity > 80) {
        alerts.push({
            event: 'High Humidity Alert',
            desc: '💧 High humidity levels. Stay hydrated and be aware of potential heat exhaustion risks.'
        });
    }

    return alerts;
}

function updateWeatherAlerts(alerts = [], weatherData = null) {
    let allAlerts = [...alerts];
    
    // Add custom alerts if weather data is available
    if (weatherData) {
        const customAlerts = generateCustomAlerts(weatherData);
        allAlerts = [...customAlerts, ...alerts];
    }

    weatherAlerts.innerHTML = allAlerts.length
        ? `
            <h3>Weather Alerts</h3>
            <div class="alerts-list">
                ${allAlerts.map(alert => `
                    <div class="alert">
                        <strong>${alert.event}</strong>
                        <p>${alert.desc}</p>
                    </div>
                `).join('')}
            </div>
        `
        : '<h3>Weather Alerts</h3><p style="color: #6b7280;">No current alerts</p>';
}

// Update charts with new weather data
function updateCharts(data) {
    // Update temperature chart
    const hourlyData = data.forecast.forecastday[0].hour;
    const labels = hourlyData.map(hour => new Date(hour.time).toLocaleTimeString('en-US', { hour: 'numeric' }));
    const temperatures = hourlyData.map(hour => hour.temp_c);

    tempChart.data.labels = labels;
    tempChart.data.datasets[0].data = temperatures;
    tempChart.update();

    // Update metrics chart
    metricsChart.data.datasets[0].data = [
        data.current.humidity,
        Math.round(data.current.wind_kph),
        Math.round(data.current.feelslike_c)
    ];
    metricsChart.update();
}

// Utility Functions
function formatDate(dateStr) {
    return new Date(dateStr).toLocaleDateString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric'
    });
}

function getAQIDescription(aqi) {
    const descriptions = {
        1: 'Good',
        2: 'Moderate',
        3: 'Unhealthy for Sensitive Groups',
        4: 'Unhealthy',
        5: 'Very Unhealthy',
        6: 'Hazardous'
    };
    return descriptions[aqi] || 'Unknown';
}

function showToast(message) {
    toast.textContent = message;
    toast.classList.remove('hidden');
    setTimeout(() => toast.classList.add('hidden'), 4000);
}

// Favorites Management
function loadFavorites() {
    const favorites = getFavorites();
    updateFavoritesList(favorites);
}

function getFavorites() {
    try {
        return JSON.parse(localStorage.getItem('favorites') || '[]');
    } catch {
        return [];
    }
}

function toggleFavorite(location) {
    const favorites = getFavorites();
    const index = favorites.indexOf(location);
    
    if (index === -1) {
        favorites.push(location);
        showToast(`Added ${location} to favorites`);
    } else {
        favorites.splice(index, 1);
        showToast(`Removed ${location} from favorites`);
    }
    
    localStorage.setItem('favorites', JSON.stringify(favorites));
    updateFavoritesList(favorites);
    
    // Update favorite button if it exists
    const favoriteBtn = document.querySelector('.favorite-btn');
    if (favoriteBtn) {
        favoriteBtn.textContent = isFavorite(location) ? '★' : '☆';
    }
}

function isFavorite(location) {
    const favorites = getFavorites();
    return favorites.includes(location);
}

function updateFavoritesList(favorites) {
    favoritesList.innerHTML = favorites.length
        ? favorites.map(location => `
            <div class="favorite-item">
                <span onclick="handleFavoriteClick('${location}')">${location}</span>
                <button onclick="toggleFavorite('${location}')">Remove</button>
            </div>
        `).join('')
        : '<p style="color: #6b7280;">No favorite locations yet</p>';
}

async function handleFavoriteClick(location) {
    try {
        const weather = await getWeatherByLocation(location);
        updateWeatherDisplay(weather);
        showToast(`Showing weather for ${location}`);
    } catch (error) {
        showToast('Error loading weather for this location');
        console.error(error);
    }
}

// Voice Search Implementation
let recognition = null;
try {
    // Initialize speech recognition
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    // Handle recognition results
    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        locationSearch.value = transcript;
        voiceSearchButton.classList.remove('listening');
        // Trigger search with the transcribed text
        searchButton.click();
    };

    recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        voiceSearchButton.classList.remove('listening');
        showToast('Voice recognition failed. Please try again.');
    };

    recognition.onend = () => {
        voiceSearchButton.classList.remove('listening');
    };

    // Voice search button click handler
    voiceSearchButton.addEventListener('click', () => {
        try {
            if (voiceSearchButton.classList.contains('listening')) {
                recognition.stop();
                voiceSearchButton.classList.remove('listening');
            } else {
                recognition.start();
                voiceSearchButton.classList.add('listening');
                showToast('Listening... Speak now');
            }
        } catch (error) {
            console.error('Speech recognition error:', error);
            showToast('Voice recognition is not supported in your browser');
        }
    });
} catch (error) {
    console.error('Speech recognition not supported:', error);
    voiceSearchButton.style.display = 'none';
}

// Initialize charts when the page loads
initializeCharts();